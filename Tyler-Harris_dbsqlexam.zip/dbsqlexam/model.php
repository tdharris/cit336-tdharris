<?php
/* ***************************************
 * DB and SQL Exam model
 * **************************************/

/* ***************************************
 * Get access to the database connection
 * **************************************/
require('model/guitar1_connection.php');

/* ***************************************
 * Get navigation items from database
 * **************************************/
function getNavigation() {
   global $db;
  try {
    $sql = 'SELECT DISTINCT products.categoryID, categoryName '
            . 'FROM products INNER JOIN categories '
            . 'WHERE products.categoryID = categories.categoryID';
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $navList = $stmt->fetchAll();
    $stmt->closeCursor();
  } catch (PDOException $ex) {
    $error_message = $ex->getMessage();
    include ('error.php');
    exit;
  }
  if (!empty($navList)) {
    return $navList;
  } else {
    return FALSE;
  }
}

/* ***************************************
 * Get the list of items by category
 * **************************************/
function getCategoryItems($category) {
  global $db;
  $query = 'SELECT * '
            . 'FROM products INNER JOIN categories '
            . 'WHERE products.categoryID = categories.categoryID '
            . 'AND products.categoryID = :category';

  try {
    $statement = $db->prepare($query);
    $statement->bindValue(':category', $category);
    $statement->execute();
    $result = $statement->fetchAll();
    $statement->closeCursor();
    return $result;  

  } catch (Exception $ex) {
    $error_message = $ex->getMessage();
    include ('error.php');
    exit;
  }
  if(!empty($results)){
    return $results;
  } else{
    return FALSE;
  }
}

/* ***************************************
 * Get item based on its key
 * **************************************/
function getItem($productid) {
    global $db;
    $query = 'SELECT * '
            . 'FROM products '
            . 'WHERE productID = :productID '
            . 'LIMIT 1';

  try {
    $statement = $db->prepare($query);
    $statement->bindValue(':productID', $productid);
    $statement->execute();
    $result = $statement->fetchAll();
    $statement->closeCursor();
    return $result;  

  } catch (Exception $ex) {
    $error_message = $ex->getMessage();
    include ('error.php');
    exit;
  }
  if(!empty($results)){
    return $results;
  } else{
    return FALSE;
  }
}

/* ***************************************
 * Build the navigation menu list
 * **************************************/
function buildNav(){
  $navItems = getNavigation();
  if(is_array($navItems)){
    $navigation = '<ul>';
    foreach ($navItems as $item) {
      $navigation .= "<li><a href='/dbsqlexam?action=q&amp;category=$item[0]' title='View our $item[1]'>$item[1]</a></li>";
    }
    $navigation .= '</ul>';
  } else {
    $navigation = 'Sorry, a critical error occurred.';
  }
  return $navigation;
}