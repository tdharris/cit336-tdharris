<?php    
    
// Create a connection to the database
// $server = 'localhost';
// $dbname = 'my_guitar_shop1';
$server = 'guitar1.tdharris.net';
$dbname = 'tdharris_guitar1';

$dsn = 'mysql:host=' . $server . ';dbname=' . $dbname;
$username = 'mgs_user';
$password = 'pa55word';
$options = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);

try {
    $db = new PDO($dsn, $username, $password, $options);
} catch (PDOException $ex) {
    $error_message = $ex->getMessage();
    include 'error.php';
    exit;
}

?>