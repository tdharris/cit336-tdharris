<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>DB and SQL Exam View</title>
        <meta name="author" content="Tyler Harris">
    </head>
    
    <body>
