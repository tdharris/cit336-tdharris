        <footer>
            <p><?php echo 'Last updated: ' . date('j F, Y \a\t h:i a ', getlastmod()); ?></p>
        </footer>
    </body>
</html>