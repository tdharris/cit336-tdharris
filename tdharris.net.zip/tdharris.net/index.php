<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A layout example that shows off a blog page with a list of posts.">

  <title>tdharris</title>
  <?php include 'views/layouts/styles.php';?>

</head>
<body>

  <div id="layout" class="pure-g">
    <?php include 'views/layouts/aside.php';?>
    <?php require 'models/db.php';?>
 
      <div class="content pure-u-1 pure-u-md-3-4">

        <section class="title">
            <h1>About Me</h1>
            <p>...</p>
        </section>

      </div>

  </div>

  <?php include 'views/layouts/scripts.php';?>

</body>
</html>
`