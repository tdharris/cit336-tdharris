<div class="content pure-u-1 pure-u-md-3-4">
    <section class="title">
        <h1>Database Error</h1>
        <p>A database error occurred.</p>
        <p>Error message: <?php echo $error_message; ?></p>
    </section>
</div> 