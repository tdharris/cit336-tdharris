<div class="sidebar pure-u-1 pure-u-md-1-4">
  <div class="header">
    <h1 class="brand-title">tdharris</h1>
    <h2 class="brand-tagline"></h2>
    <br>

    <ul class="list-inline social">
      <li>
          <a target="_blank" href="https://www.facebook.com/tylerdavidharris" class="btn-social btn-outline facebook"><i class="fa fa-fw fa-facebook"></i></a>
      </li>
      <li>
          <a target="_blank" href="https://google.com/+TylerHarristdh" class="btn-social btn-outline google-plus"><i class="fa fa-fw fa-google-plus"></i></a>
      </li>
      <li>
          <a target="_blank" href="https://twitter.com/tdharris" class="btn-social btn-outline twitter"><i class="fa fa-fw fa-twitter"></i></a>
      </li>
      <li>
          <a target="_blank" href="https://www.linkedin.com/in/tylerdavidharris" class="btn-social btn-outline linkedin"><i class="fa fa-fw fa-linkedin"></i></a>
      </li>
    </ul>

    <div class="pure-menu">
        <ul class="pure-menu-list">
            <!-- <li class="pure-menu-heading">NAVIGATION</li> -->
            <li class="pure-menu-item"><a href="#" class="pure-menu-link">About Me</a></li>
            <li class="pure-menu-item"><a href="#" class="pure-menu-link">Blog</a></li>
            <li class="pure-menu-item"><a href="#" class="pure-menu-link">Portfolio</a></li>
            <li class="pure-menu-item"><a href="#" class="pure-menu-link">Contact</a></li>
        </ul>
    </div>

  </div>
</div>
