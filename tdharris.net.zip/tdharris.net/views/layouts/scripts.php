<!-- JS -->
<script src="js/rainbow-custom.min.js"></script>