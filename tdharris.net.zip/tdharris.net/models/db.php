<?php 

	class Database {
        
        private $host = "showcase.tdharris.net";
        private $user = "tdharris_admin"; 
        private $pass = "mylittlesecret"; 
        private $dbname = "tdharris_showcase";
 
	    private $dbh;
        private $error;
        private $stmt;
        
        public function __construct() { 

            $dsn = 'mysql:host=' . $this -> host . ';dbname=' . $this-> dbname . ';charset=utf8';
            $options = array(PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8");

            try {
                $this -> dbh = new PDO($dsn, $this -> user, $this -> pass, $options);
            } catch (PDOException $e) {
//                $this -> error = $e -> getMessage();
                $error_message = $e->getMessage();
                include 'error.php';
                exit;
            }

            try {
                echo $this->dsn;
                $this->dbh = new PDO('mysql:host=' . $host . ';dbname=' . $dbname, $this->username, $this->password, $this->options);
                /*** echo a message saying we have connected ***/
                echo 'Connected to database'; // Test with this string
            }
            catch(PDOException $e) {
                $error_message = $e->getMessage();
                include 'error.php';
                exit;
            }
        }
        
       public function __destruct() {
           $this->dbh = NULL; // Setting the handler to NULL closes the connection propperly
       }

	} 

	$db = new Database;

?>