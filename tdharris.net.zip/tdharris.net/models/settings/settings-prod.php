<?php

	/**
	 * Database config variables
	 */

	define("DB_HOST", "showcase.tdharris.net");
	define("DB_USER", "tdharris_admin");
	define("DB_PASS", "mylittlesecret");
	define("DB_NAME", "showcase");
    define("DSN", 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME);

	// PROD
	// define("DB_HOST", "showcase.tdharris.net");
	// define("DB_USER", "tdharris_admin");
	// define("DB_PASSWORD", "mylittlesecret");
	// define("DB_DATABASE", "tdharris_showcase");

	// $server = 'showcase.tdharris.net';
	// $dbname = 'tdharris_showcase';
	// $dsn = 'mysql:host=' . $server . ';dbname=' . $dbname;
	// $user = 'tdharris_admin';
	// $password = 'mylittlesecret';

?>